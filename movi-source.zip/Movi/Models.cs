using System.Text.Json;
using System.Text.Json.Serialization;

namespace Movi.Models;

/// Decodes a bool that may arrive as true/false or 1/0.
public class FlexibleBoolConverter : JsonConverter<bool>
{
    public override bool Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        return reader.TokenType switch
        {
            JsonTokenType.True => true,
            JsonTokenType.False => false,
            JsonTokenType.Number => reader.GetInt32() != 0,
            JsonTokenType.String => reader.GetString() is string s &&
                (s == "1" || s.Equals("true", StringComparison.OrdinalIgnoreCase)),
            _ => false
        };
    }

    public override void Write(Utf8JsonWriter writer, bool value, JsonSerializerOptions options)
        => writer.WriteBooleanValue(value);
}

// ---------- Auth ----------

public class ApiUser
{
    [JsonPropertyName("id")] public int Id { get; set; }
    [JsonPropertyName("username")] public string Username { get; set; } = "";
    [JsonPropertyName("email")] public string Email { get; set; } = "";
    [JsonPropertyName("is_admin")]
    [JsonConverter(typeof(FlexibleBoolConverter))]
    public bool IsAdmin { get; set; }
}

public class LoginResponse
{
    [JsonPropertyName("ok")] public bool Ok { get; set; }
    [JsonPropertyName("user")] public ApiUser? User { get; set; }
    [JsonPropertyName("error")] public string? Error { get; set; }
}

public class Profile
{
    [JsonPropertyName("id")] public int Id { get; set; }
    [JsonPropertyName("name")] public string Name { get; set; } = "";
    [JsonPropertyName("color")] public string Color { get; set; } = "#e50914";
}

public class ProfilesResponse
{
    [JsonPropertyName("profiles")] public List<Profile> Profiles { get; set; } = new();
    [JsonPropertyName("current_profile_id")] public int? CurrentProfileId { get; set; }
}

// ---------- Home ----------

public class HomeItem
{
    [JsonPropertyName("item_id")] public int? ItemIdAlt { get; set; }
    [JsonPropertyName("id")] public int? IdAlt { get; set; }
    public int ItemId => ItemIdAlt ?? IdAlt ?? 0;

    [JsonPropertyName("title")] public string Title { get; set; } = "";
    [JsonPropertyName("year")] public int? Year { get; set; }
    [JsonPropertyName("poster_url")] public string? PosterUrl { get; set; }
    [JsonPropertyName("kind")] public string Kind { get; set; } = "";
    [JsonPropertyName("position_seconds")] public double? PositionSeconds { get; set; }
    [JsonPropertyName("duration_seconds")] public double? DurationSeconds { get; set; }
    [JsonPropertyName("show_title")] public string? ShowTitle { get; set; }
    [JsonPropertyName("season_no")] public int? SeasonNo { get; set; }
    [JsonPropertyName("episode_no")] public int? EpisodeNo { get; set; }

    public double? Progress
    {
        get
        {
            if (PositionSeconds is null || DurationSeconds is null || DurationSeconds <= 0) return null;
            return Math.Min(1, Math.Max(0, PositionSeconds.Value / DurationSeconds.Value));
        }
    }

    public string DisplayTitle => !string.IsNullOrEmpty(ShowTitle) ? ShowTitle : Title;
}

public class HomeRow
{
    [JsonPropertyName("key")] public string Key { get; set; } = "";
    [JsonPropertyName("title")] public string Title { get; set; } = "";
    [JsonPropertyName("kind")] public string Kind { get; set; } = "";
    [JsonPropertyName("items")] public List<HomeItem> Items { get; set; } = new();
}

public class HomeResponse
{
    [JsonPropertyName("hero")] public HomeItem? Hero { get; set; }
    [JsonPropertyName("rows")] public List<HomeRow> Rows { get; set; } = new();
}

// ---------- Detail ----------

public class PlaybackInfo
{
    [JsonPropertyName("file_url")] public string? FileUrl { get; set; }
    [JsonPropertyName("resume_hint_sec")] public double? ResumeHintSec { get; set; }
    [JsonPropertyName("resume_label")] public string? ResumeLabel { get; set; }
    [JsonPropertyName("error")] public string? Error { get; set; }
}

public class WatchProgress
{
    [JsonPropertyName("position_seconds")] public double? PositionSeconds { get; set; }
    [JsonPropertyName("duration_seconds")] public double? DurationSeconds { get; set; }
}

public class MovieDetail
{
    [JsonPropertyName("id")] public int Id { get; set; }
    [JsonPropertyName("title")] public string Title { get; set; } = "";
    [JsonPropertyName("year")] public int? Year { get; set; }
    [JsonPropertyName("overview")] public string? Overview { get; set; }
    [JsonPropertyName("poster_url")] public string? PosterUrl { get; set; }
    [JsonPropertyName("backdrop_url")] public string? BackdropUrl { get; set; }
    [JsonPropertyName("genres")] public string? Genres { get; set; }
    [JsonPropertyName("is_favorite")] public bool? IsFavorite { get; set; }
    [JsonPropertyName("progress")] public WatchProgress? Progress { get; set; }
    [JsonPropertyName("playback")] public PlaybackInfo? Playback { get; set; }
}

public class Episode
{
    [JsonPropertyName("id")] public int Id { get; set; }
    [JsonPropertyName("episode_number")] public int? EpisodeNumber { get; set; }
    [JsonPropertyName("title")] public string? Title { get; set; }
    [JsonPropertyName("overview")] public string? Overview { get; set; }
    [JsonPropertyName("still_url")] public string? StillUrl { get; set; }
    [JsonPropertyName("position_seconds")] public double? PositionSeconds { get; set; }
    [JsonPropertyName("duration_seconds")] public double? DurationSeconds { get; set; }

    public double? Progress
    {
        get
        {
            if (PositionSeconds is null || DurationSeconds is null || DurationSeconds <= 0) return null;
            return Math.Min(1, Math.Max(0, PositionSeconds.Value / DurationSeconds.Value));
        }
    }

    public string Label => $"E{EpisodeNumber ?? 0} · {Title ?? "Episode"}";
}

public class Season
{
    [JsonPropertyName("id")] public int Id { get; set; }
    [JsonPropertyName("season_number")] public int? SeasonNumber { get; set; }
    [JsonPropertyName("episodes")] public List<Episode>? Episodes { get; set; }
}

public class ShowDetail
{
    [JsonPropertyName("id")] public int Id { get; set; }
    [JsonPropertyName("title")] public string Title { get; set; } = "";
    [JsonPropertyName("year")] public int? Year { get; set; }
    [JsonPropertyName("overview")] public string? Overview { get; set; }
    [JsonPropertyName("poster_url")] public string? PosterUrl { get; set; }
    [JsonPropertyName("backdrop_url")] public string? BackdropUrl { get; set; }
    [JsonPropertyName("genres")] public string? Genres { get; set; }
    [JsonPropertyName("is_favorite")] public bool? IsFavorite { get; set; }
    [JsonPropertyName("seasons")] public List<Season>? Seasons { get; set; }
}

public class NextRef
{
    [JsonPropertyName("id")] public int Id { get; set; }
    [JsonPropertyName("episode_number")] public int? EpisodeNumber { get; set; }
    [JsonPropertyName("season_number")] public int? SeasonNumber { get; set; }
}

public class EpisodeDetail
{
    [JsonPropertyName("id")] public int Id { get; set; }
    [JsonPropertyName("title")] public string? Title { get; set; }
    [JsonPropertyName("overview")] public string? Overview { get; set; }
    [JsonPropertyName("episode_number")] public int? EpisodeNumber { get; set; }
    [JsonPropertyName("season_number")] public int? SeasonNumber { get; set; }
    [JsonPropertyName("show_title")] public string? ShowTitle { get; set; }
    [JsonPropertyName("show_id")] public int? ShowId { get; set; }
    [JsonPropertyName("playback")] public PlaybackInfo? Playback { get; set; }
    [JsonPropertyName("next")] public NextRef? Next { get; set; }
}

// ---------- Search / favorites ----------

public class SearchResponse
{
    [JsonPropertyName("movies")] public List<HomeItem>? Movies { get; set; }
    [JsonPropertyName("shows")] public List<HomeItem>? Shows { get; set; }
}

public class FavoritesResponse
{
    [JsonPropertyName("movies")] public List<HomeItem>? Movies { get; set; }
    [JsonPropertyName("shows")] public List<HomeItem>? Shows { get; set; }
}

// ---------- Downloads ----------

public class DownloadStartResponse
{
    [JsonPropertyName("ok")] public bool Ok { get; set; }
    [JsonPropertyName("job_id")] public string? JobId { get; set; }
    [JsonPropertyName("error")] public string? Error { get; set; }
}

public class DownloadStatusResponse
{
    [JsonPropertyName("status")] public string? Status { get; set; }
    [JsonPropertyName("progress")] public double? Progress { get; set; }
    [JsonPropertyName("dl_url")] public string? DlUrl { get; set; }
    [JsonPropertyName("filename")] public string? Filename { get; set; }
    [JsonPropertyName("error")] public string? Error { get; set; }
    [JsonPropertyName("error_code")] public string? ErrorCode { get; set; }
}

public enum DownloadState { Preparing, Downloading, Done, Failed }

public class DownloadItem
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    public string Kind { get; set; } = ""; // "movie" | "episode"
    public int LibraryId { get; set; }
    public string Title { get; set; } = "";
    public string? PosterUrl { get; set; }
    public string Filename { get; set; } = "";
    public DownloadState State { get; set; } = DownloadState.Preparing;
    public double Progress { get; set; }
    public long? SizeBytes { get; set; }
    public string? JobId { get; set; }
    public DateTime? DownloadedAt { get; set; }

    public string StatusLabel => State switch
    {
        DownloadState.Preparing => "Preparing…",
        DownloadState.Downloading => $"{(int)(Progress * 100)}%",
        DownloadState.Done => SizeLabel ?? "Downloaded",
        DownloadState.Failed => "Failed — tap to retry",
        _ => ""
    };

    public string? SizeLabel
    {
        get
        {
            if (SizeBytes is null or <= 0) return null;
            if (SizeBytes >= 1_073_741_824) return $"{SizeBytes / 1_073_741_824.0:F1} GB";
            return $"{SizeBytes / 1_048_576.0:F0} MB";
        }
    }
}
