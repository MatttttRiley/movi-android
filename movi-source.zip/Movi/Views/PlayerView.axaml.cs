using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Markup.Xaml;
using Avalonia.Threading;
using LibVLCSharp.Shared;
using Movi.Models;
using Movi.Services;

namespace Movi.Views;

public partial class PlayerView : UserControl
{
    private static LibVLC? _libVLC;
    private MediaPlayer? _player;
    private readonly PlayRequest _req;
    private readonly Action _onClose;
    private readonly DispatcherTimer _tick;
    private string? _streamUrl;
    private double _durationSec;
    private bool _seeking;
    private DateTime _lastReport = DateTime.MinValue;
    private NextRef? _next;

    public PlayerView(PlayRequest req, Action onClose)
    {
        _req = req;
        _onClose = onClose;
        InitializeComponent();

        this.FindControl<Button>("CloseButton")!.Click += (_, _) => Close();
        var pp = this.FindControl<Button>("PlayPause")!;
        pp.Click += (_, _) => TogglePlay();
        this.FindControl<Button>("Back10")!.Click += (_, _) => SeekBy(-10);
        this.FindControl<Button>("Fwd10")!.Click += (_, _) => SeekBy(10);
        var seek = this.FindControl<Slider>("SeekBar")!;
        seek.AddHandler(InputElement.PointerPressedEvent, (_, _) => _seeking = true, Avalonia.Interactivity.RoutingStrategies.Tunnel);
        seek.AddHandler(InputElement.PointerReleasedEvent, (_, _) =>
        {
            _seeking = false;
            if (_player != null && _durationSec > 0)
                _player.Time = (long)(seek.Value / 1000 * _durationSec * 1000);
        }, Avalonia.Interactivity.RoutingStrategies.Tunnel);
        this.FindControl<Border>("TapZone")!.PointerPressed += (_, _) =>
        {
            var c = this.FindControl<Grid>("Controls")!;
            c.IsVisible = !c.IsVisible;
        };

        _tick = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
        _tick.Tick += (_, _) => OnTick();

        _ = LoadAsync();
    }

    private static LibVLC GetLibVLC()
    {
        if (_libVLC == null)
        {
            Core.Initialize();
            _libVLC = new LibVLC("--no-video-title-show");
        }
        return _libVLC;
    }

    private async Task LoadAsync()
    {
        var spinner = this.FindControl<ProgressBar>("Spinner")!;
        spinner.IsVisible = true;
        try
        {
            double startAt = 0;
            if (!string.IsNullOrEmpty(_req.LocalPath))
            {
                _streamUrl = new Uri(_req.LocalPath).AbsoluteUri;
            }
            else if (_req.Kind == "movie")
            {
                var d = await ApiClient.Shared.GetMovieAsync(_req.ItemId);
                _streamUrl = d.Playback?.FileUrl;
                startAt = d.Playback?.ResumeHintSec ?? 0;
                if (!string.IsNullOrEmpty(d.Playback?.Error)) throw new ApiException(d.Playback.Error);
            }
            else
            {
                var d = await ApiClient.Shared.GetEpisodeAsync(_req.ItemId);
                _streamUrl = d.Playback?.FileUrl;
                startAt = d.Playback?.ResumeHintSec ?? 0;
                _next = d.Next;
                if (!string.IsNullOrEmpty(d.Playback?.Error)) throw new ApiException(d.Playback.Error);
            }
            if (string.IsNullOrEmpty(_streamUrl)) throw new ApiException("No playable stream found.");

            await Dispatcher.UIThread.InvokeAsync(() =>
            {
                var vv = this.FindControl<LibVLCSharp.Avalonia.VideoView>("VideoView")!;
                _player = new MediaPlayer(GetLibVLC());
                _player.EndReached += (_, _) => Dispatcher.UIThread.Post(OnEnded);
                _player.LengthChanged += (_, e) => _durationSec = e.Length / 1000.0;
                vv.MediaPlayer = _player;
                _player.Play(new Media(GetLibVLC(), _streamUrl, FromType.FromLocation));
                if (startAt > 5) _player.Time = (long)(startAt * 1000);
                this.FindControl<TextBlock>("TitleText")!.Text = _req.Title;
                this.FindControl<Grid>("Controls")!.IsVisible = true;
            });
            _tick.Start();
        }
        catch (ApiException ex)
        {
            var t = this.FindControl<TextBlock>("ErrorText")!;
            t.Text = ex.Message; t.IsVisible = true;
        }
        finally { spinner.IsVisible = false; }
    }

    private void OnTick()
    {
        if (_player == null || _seeking) return;
        var pos = _player.Time / 1000.0;
        var seek = this.FindControl<Slider>("SeekBar")!;
        if (_durationSec > 0) seek.Value = pos / _durationSec * 1000;
        this.FindControl<TextBlock>("TimeText")!.Text = $"{Fmt(pos)} / {Fmt(_durationSec)}";
        this.FindControl<Button>("PlayPause")!.Content = _player.IsPlaying ? "⏸" : "▶";

        // Report progress every ~15s (skip for local files).
        if (string.IsNullOrEmpty(_req.LocalPath) && _durationSec > 0 &&
            DateTime.UtcNow - _lastReport > TimeSpan.FromSeconds(15))
        {
            _lastReport = DateTime.UtcNow;
            _ = ApiClient.Shared.ReportProgressAsync(_req.Kind, _req.ItemId, pos, _durationSec);
        }
    }

    private void OnEnded()
    {
        // Final progress report, then auto-play next episode if there is one.
        if (string.IsNullOrEmpty(_req.LocalPath) && _durationSec > 0)
            _ = ApiClient.Shared.ReportProgressAsync(_req.Kind, _req.ItemId, _durationSec, _durationSec);
        if (_next != null)
        {
            Dispatcher.UIThread.Post(() =>
            {
                Close();
                AppState.Shared.RequestPlay(new PlayRequest
                {
                    Kind = "episode", ItemId = _next.Id,
                    Title = $"Next episode",
                });
            });
        }
        else Dispatcher.UIThread.Post(Close);
    }

    private void TogglePlay()
    {
        if (_player == null) return;
        if (_player.IsPlaying) _player.Pause();
        else _player.Play();
    }

    private void SeekBy(int seconds)
    {
        if (_player == null) return;
        _player.Time = Math.Max(0, _player.Time + seconds * 1000);
    }

    private static string Fmt(double s)
    {
        if (s < 0 || double.IsNaN(s)) s = 0;
        var t = TimeSpan.FromSeconds(s);
        return t.TotalHours >= 1 ? t.ToString(@"h\:mm\:ss") : t.ToString(@"m\:ss");
    }

    private void Close()
    {
        _tick.Stop();
        try
        {
            // Final progress report on close.
            if (_player != null && string.IsNullOrEmpty(_req.LocalPath) && _durationSec > 0)
                _ = ApiClient.Shared.ReportProgressAsync(_req.Kind, _req.ItemId, _player.Time / 1000.0, _durationSec);
            _player?.Stop();
            _player?.Dispose();
        }
        catch { }
        _player = null;
        _onClose();
    }

    private void InitializeComponent() => AvaloniaXamlLoader.Load(this);
}
