using Avalonia.Controls;
using Avalonia.Markup.Xaml;
using Movi.Services;

namespace Movi.Views;

public partial class ShellView : UserControl
{
    public ShellView()
    {
        InitializeComponent();
        var host = this.FindControl<ContentControl>("Host")!;
        void Show()
        {
            host.Content = AppState.Shared.Screen switch
            {
                AppScreen.Login => new LoginView(),
                AppScreen.Profiles => new ProfilesView(),
                _ => new MainTabsView(),
            };
        }
        AppState.Shared.PropertyChanged += (_, e) =>
        {
            if (e.PropertyName == nameof(AppState.Screen))
                Avalonia.Threading.Dispatcher.UIThread.Post(Show);
        };
        Show();
    }

    private void InitializeComponent() => AvaloniaXamlLoader.Load(this);
}
