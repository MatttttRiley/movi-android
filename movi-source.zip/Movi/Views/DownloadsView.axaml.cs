using Avalonia.Controls;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Media;
using Movi.Models;
using Movi.Services;

namespace Movi.Views;

public partial class DownloadsView : UserControl, IRefreshable
{
    public DownloadsView()
    {
        InitializeComponent();
        DownloadManager.Shared.Changed += Render;
        Render();
    }

    public void Refresh() => Render();

    private void Render()
    {
        var body = this.FindControl<StackPanel>("Body");
        if (body == null) return;
        Avalonia.Threading.Dispatcher.UIThread.Post(() =>
        {
            body.Children.Clear();
            var items = DownloadManager.Shared.Items;
            if (items.Count == 0)
            {
                body.Children.Add(new TextBlock
                {
                    Text = "No downloads yet.\nTap ⭳ Download on any movie or episode to watch it offline.",
                    Foreground = new SolidColorBrush(Color.FromRgb(0x8E, 0x8E, 0x99)),
                    TextWrapping = TextWrapping.Wrap,
                });
                return;
            }
            foreach (var item in items)
                body.Children.Add(Row(item));
        });
    }

    private Control Row(DownloadItem item)
    {
        var grid = new Grid { ColumnDefinitions = new("64,*,Auto"), Margin = new(0, 4) };
        grid.Children.Add(new Border
        {
            CornerRadius = new(6), ClipToBounds = true, Width = 64, Height = 96,
            Background = new SolidColorBrush(Color.FromRgb(0x1A, 0x1A, 0x24)),
            Child = new AsyncImage { Url = item.PosterUrl, Stretch = Stretch.UniformToFill },
        });

        var mid = new StackPanel { Spacing = 6, Margin = new(12, 0), VerticalAlignment = VerticalAlignment.Center };
        Grid.SetColumn(mid, 1);
        mid.Children.Add(new TextBlock { Text = item.Title, FontWeight = FontWeight.Bold, TextWrapping = TextWrapping.Wrap, MaxLines = 2 });
        if (item.State is DownloadState.Preparing or DownloadState.Downloading)
            mid.Children.Add(new ProgressBar { Value = item.Progress * 100, Maximum = 100, Height = 4, Foreground = new SolidColorBrush(Color.FromRgb(0xE5, 0x09, 0x14)) });
        mid.Children.Add(new TextBlock
        {
            Text = item.StatusLabel, FontSize = 12,
            Foreground = new SolidColorBrush(item.State == DownloadState.Failed
                ? Color.FromRgb(0xE5, 0x09, 0x14) : Color.FromRgb(0x8E, 0x8E, 0x99)),
        });
        grid.Children.Add(mid);

        var right = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 6, VerticalAlignment = VerticalAlignment.Center };
        Grid.SetColumn(right, 2);
        if (item.State == DownloadState.Done)
        {
            var play = new Button { Content = "▶", };
        play.Classes.Add("movi-ghost");
            play.Click += (_, _) =>
            {
                var path = DownloadManager.Shared.LocalPath(item);
                if (path != null)
                    AppState.Shared.RequestPlay(new PlayRequest { Kind = item.Kind, ItemId = item.LibraryId, Title = item.Title, LocalPath = path });
            };
            right.Children.Add(play);
        }
        else if (item.State == DownloadState.Failed)
        {
            var retry = new Button { Content = "↻", };
        retry.Classes.Add("movi-ghost");
            retry.Click += (_, _) => DownloadManager.Shared.Start(item.Kind, item.LibraryId, item.Title, item.PosterUrl);
            right.Children.Add(retry);
        }
        var del = new Button { Content = "✕", };
        del.Classes.Add("movi-ghost");
        del.Click += (_, _) => DownloadManager.Shared.Delete(item);
        right.Children.Add(del);
        grid.Children.Add(right);

        var tap = new Button
        {
            Content = grid, Background = Brushes.Transparent, Padding = new(0, 4),
            BorderThickness = new(0), HorizontalAlignment = HorizontalAlignment.Stretch,
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
        };
        tap.Click += (_, _) =>
        {
            var path = DownloadManager.Shared.LocalPath(item);
            if (item.State == DownloadState.Done && path != null)
                AppState.Shared.RequestPlay(new PlayRequest { Kind = item.Kind, ItemId = item.LibraryId, Title = item.Title, LocalPath = path });
            else if (item.State == DownloadState.Failed)
                DownloadManager.Shared.Start(item.Kind, item.LibraryId, item.Title, item.PosterUrl);
        };
        return tap;
    }

    private void InitializeComponent() => AvaloniaXamlLoader.Load(this);
}
