using Avalonia;
using Avalonia.Controls;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Media;
using Movi.Models;
using Movi.Services;

namespace Movi.Views;

public partial class HomeView : UserControl, IRefreshable
{
    public HomeView()
    {
        InitializeComponent();
        _ = LoadAsync();
    }

    public void Refresh() => _ = LoadAsync();

    private async Task LoadAsync()
    {
        var rows = this.FindControl<StackPanel>("Rows")!;
        var err = this.FindControl<TextBlock>("ErrorText")!;
        var spinner = this.FindControl<ProgressBar>("Spinner")!;
        spinner.IsVisible = true; err.IsVisible = false;
        try
        {
            var home = await ApiClient.Shared.GetHomeAsync();
            rows.Children.Clear();
            if (home.Hero != null) rows.Children.Add(BuildHero(home.Hero));
            foreach (var row in home.Rows)
            {
                if (row.Items.Count == 0) continue;
                rows.Children.Add(BuildRow(row));
            }
        }
        catch (ApiException ex)
        {
            if (ex.SessionExpired) AppState.Shared.OnSessionExpired();
            else Ui.ShowError(err, ex.Message);
        }
        finally { spinner.IsVisible = false; }
    }

    private Control BuildHero(HomeItem hero)
    {
        var grid = new Grid { Height = 300 };
        var bg = new AsyncImage
        {
            Url = hero.PosterUrl, Stretch = Stretch.UniformToFill,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            VerticalAlignment = VerticalAlignment.Stretch,
        };
        var shade = new Border
        {
            Background = new LinearGradientBrush
            {
                StartPoint = new RelativePoint(0, 1, RelativeUnit.Relative),
                EndPoint = new RelativePoint(0, 0, RelativeUnit.Relative),
                GradientStops = new GradientStops
                {
                    new(Color.FromRgb(0x0B, 0x0B, 0x10), 0),
                    new(Color.FromArgb(0x00, 0x0B, 0x0B, 0x10), 0.7),
                }
            }
        };
        var panel = new StackPanel
        {
            Spacing = 10, Margin = new(20, 0, 20, 20),
            VerticalAlignment = VerticalAlignment.Bottom,
        };
        panel.Children.Add(new TextBlock { Text = hero.DisplayTitle, FontSize = 30, FontWeight = FontWeight.Black, TextWrapping = TextWrapping.Wrap });
        if (hero.Year is int y)
            panel.Children.Add(new TextBlock { Text = y.ToString(), Foreground = new SolidColorBrush(Color.FromRgb(0x8E, 0x8E, 0x99)) });
        var play = new Button { Content = "▶  Play", };
        play.Classes.Add("movi-primary");
        play.Click += (_, _) => PlayHero(hero);
        var more = new Button { Content = "More Info", };
        more.Classes.Add("movi-ghost");
        more.Click += (_, _) => OpenDetail(hero);
        var btns = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 10 };
        btns.Children.Add(play); btns.Children.Add(more);
        panel.Children.Add(btns);

        grid.Children.Add(bg); grid.Children.Add(shade); grid.Children.Add(panel);
        return grid;
    }

    private void PlayHero(HomeItem hero)
    {
        var dest = hero.Kind switch
        {
            "movie" => new PlayRequest { Kind = "movie", ItemId = hero.ItemId, Title = hero.Title },
            "episode" => new PlayRequest { Kind = "episode", ItemId = hero.ItemId, Title = hero.Title },
            "show" => null,
            _ => null,
        };
        if (dest != null) AppState.Shared.RequestPlay(dest);
        else OpenDetail(hero);
    }

    private void OpenDetail(HomeItem item)
    {
        switch (item.Kind)
        {
            case "movie": AppState.Shared.PushView(new MovieDetailView(item.ItemId)); break;
            case "show": AppState.Shared.PushView(new ShowDetailView(item.ItemId)); break;
            case "episode": AppState.Shared.PushView(new ShowDetailView(0, highlightEpisode: item.ItemId)); break;
        }
    }

    private Control BuildRow(HomeRow row)
    {
        var stack = new StackPanel { Spacing = 8 };
        stack.Children.Add(new TextBlock
        {
            Text = row.Title, FontSize = 17, FontWeight = FontWeight.Bold, Margin = new(16, 0, 0, 0)
        });
        var scroll = new ScrollViewer
        {
            HorizontalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto,
            VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Disabled,
            Margin = new(16, 0, 0, 0),
        };
        var panel = new StackPanel { Orientation = Orientation.Horizontal };
        foreach (var item in row.Items)
        {
            var captured = item;
            panel.Children.Add(Ui.PosterCard(captured, () => OpenDetail(captured)));
        }
        scroll.Content = panel;
        stack.Children.Add(scroll);
        return stack;
    }

    private void InitializeComponent() => AvaloniaXamlLoader.Load(this);
}
