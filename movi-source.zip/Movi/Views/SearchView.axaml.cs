using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Markup.Xaml;
using Avalonia.Media;
using Movi.Models;
using Movi.Services;

namespace Movi.Views;

public partial class SearchView : UserControl, IRefreshable
{
    private CancellationTokenSource? _cts;

    public SearchView()
    {
        InitializeComponent();
        var box = this.FindControl<TextBox>("QueryBox")!;
        box.KeyDown += (_, e) =>
        {
            if (e.Key == Key.Enter) _ = SearchAsync(box.Text ?? "");
        };
        // Debounced live search
        box.TextChanged += (_, _) =>
        {
            _cts?.Cancel();
            _cts = new CancellationTokenSource();
            var token = _cts.Token;
            var q = box.Text ?? "";
            Task.Run(async () =>
            {
                try
                {
                    await Task.Delay(500, token);
                    await Avalonia.Threading.Dispatcher.UIThread.InvokeAsync(() => SearchAsync(q));
                }
                catch (TaskCanceledException) { }
            }, token);
        };
    }

    public void Refresh() { }

    private async Task SearchAsync(string q)
    {
        var host = this.FindControl<StackPanel>("Results")!;
        var err = this.FindControl<TextBlock>("ErrorText")!;
        err.IsVisible = false;
        if (string.IsNullOrWhiteSpace(q)) { host.Children.Clear(); return; }
        try
        {
            var resp = await ApiClient.Shared.SearchAsync(q.Trim());
            host.Children.Clear();
            AddSection(host, "Movies", resp.Movies, "movie");
            AddSection(host, "Shows", resp.Shows, "show");
            if ((resp.Movies?.Count ?? 0) + (resp.Shows?.Count ?? 0) == 0)
                host.Children.Add(new TextBlock { Text = "No results.", Foreground = new SolidColorBrush(Color.FromRgb(0x8E, 0x8E, 0x99)) });
        }
        catch (ApiException ex)
        {
            if (ex.SessionExpired) AppState.Shared.OnSessionExpired();
            else Ui.ShowError(err, ex.Message);
        }
    }

    private static void AddSection(StackPanel host, string title, List<HomeItem>? items, string kind)
    {
        if (items is not { Count: > 0 }) return;
        host.Children.Add(new TextBlock { Text = title, FontSize = 17, FontWeight = FontWeight.Bold });
        var wrap = new WrapPanel { Orientation = Avalonia.Layout.Orientation.Horizontal };
        foreach (var item in items)
        {
            var captured = item;
            captured.Kind = kind;
            wrap.Children.Add(Ui.PosterCard(captured, () =>
            {
                if (kind == "movie") AppState.Shared.PushView(new MovieDetailView(captured.ItemId));
                else AppState.Shared.PushView(new ShowDetailView(captured.ItemId));
            }, 100));
        }
        host.Children.Add(wrap);
    }

    private void InitializeComponent() => AvaloniaXamlLoader.Load(this);
}
