using Avalonia.Controls;
using Avalonia.Markup.Xaml;
using Movi.Services;

namespace Movi.Views;

public partial class AccountView : UserControl, IRefreshable
{
    public AccountView()
    {
        InitializeComponent();
        this.FindControl<Button>("LogoutButton")!.Click += async (_, _) =>
        {
            try { await ApiClient.Shared.LogoutAsync(); } catch { }
            AppState.Shared.Logout();
        };
        this.FindControl<Button>("ProfileButton")!.Click += (_, _) =>
        {
            AppState.Shared.Screen = AppScreen.Profiles;
        };
        Refresh();
    }

    public void Refresh()
    {
        var info = this.FindControl<TextBlock>("InfoText")!;
        var u = AppState.Shared.User;
        var p = AppState.Shared.Profile;
        info.Text = u == null ? "" : $"{u.Email}\nWatching as: {p?.Name ?? "—"}";
    }

    private void InitializeComponent() => AvaloniaXamlLoader.Load(this);
}
