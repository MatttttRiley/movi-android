using Avalonia.Controls;
using Avalonia.Markup.Xaml;
using Movi.Services;

namespace Movi.Views;

public partial class MainTabsView : UserControl
{
    private readonly Stack<UserControl> _stack = new();
    private readonly UserControl[] _tabs;
    private readonly Button[] _tabButtons;

    public MainTabsView()
    {
        InitializeComponent();
        AppState.Shared.Tabs = this;
        _tabs = new UserControl[] { new HomeView(), new SearchView(), new LibraryView(), new DownloadsView(), new AccountView() };
        _tabButtons = new[]
        {
            this.FindControl<Button>("TabHome")!, this.FindControl<Button>("TabSearch")!,
            this.FindControl<Button>("TabList")!, this.FindControl<Button>("TabDownloads")!,
            this.FindControl<Button>("TabProfile")!,
        };
        for (int i = 0; i < _tabButtons.Length; i++)
        {
            int idx = i;
            _tabButtons[i].Click += (_, _) => { _stack.Clear(); ShowTab(idx); };
        }
        AppState.Shared.PropertyChanged += (_, e) =>
        {
            if (e.PropertyName == nameof(AppState.MainTab))
                Avalonia.Threading.Dispatcher.UIThread.Post(() => { _stack.Clear(); ShowTab(AppState.Shared.MainTab); });
        };
        AppState.Shared.PlayRequested += OnPlayRequested;
        ShowTab(0);
    }

    private void ShowTab(int idx)
    {
        for (int i = 0; i < _tabButtons.Length; i++)
            _tabButtons[i].Classes.Set("active", i == idx);
        this.FindControl<ContentControl>("ContentHost")!.Content = _tabs[idx];
        if (_tabs[idx] is IRefreshable r) r.Refresh();
    }

    public void Push(UserControl view)
    {
        _stack.Push(view);
        this.FindControl<ContentControl>("ContentHost")!.Content = view;
    }

    public void Pop()
    {
        if (_stack.Count > 0) _stack.Pop();
        var top = _stack.Count > 0 ? _stack.Peek() : null;
        if (top != null)
            this.FindControl<ContentControl>("ContentHost")!.Content = top;
        else
            ShowTab(AppState.Shared.MainTab);
    }

    private void OnPlayRequested(PlayRequest req)
    {
        var host = this.FindControl<ContentControl>("PlayerHost")!;
        var player = new PlayerView(req, () =>
        {
            host.Content = null;
            host.IsVisible = false;
        });
        host.Content = player;
        host.IsVisible = true;
    }

    private void InitializeComponent() => AvaloniaXamlLoader.Load(this);
}

/// Views that reload when their tab is selected.
public interface IRefreshable { void Refresh(); }
