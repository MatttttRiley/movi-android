using Avalonia.Controls;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Media;
using Movi.Models;
using Movi.Services;

namespace Movi.Views;

public partial class ShowDetailView : UserControl
{
    private readonly int _id;
    private ShowDetail? _show;

    public ShowDetailView(int id, int highlightEpisode = 0)
    {
        _id = id;
        InitializeComponent();
        this.FindControl<Button>("BackButton")!.Click += (_, _) => AppState.Shared.PopView();
        _ = LoadAsync();
    }

    private async Task LoadAsync()
    {
        var body = this.FindControl<StackPanel>("Body")!;
        var err = this.FindControl<TextBlock>("ErrorText")!;
        var spinner = this.FindControl<ProgressBar>("Spinner")!;
        spinner.IsVisible = true;
        try
        {
            _show = await ApiClient.Shared.GetShowAsync(_id);
            body.Children.Clear();
            BuildBody(body, _show);
        }
        catch (ApiException ex)
        {
            if (ex.SessionExpired) AppState.Shared.OnSessionExpired();
            else Ui.ShowError(err, ex.Message);
        }
        finally { spinner.IsVisible = false; }
    }

    private void BuildBody(StackPanel body, ShowDetail s)
    {
        var banner = new Grid { Height = 220 };
        banner.Children.Add(new AsyncImage { Url = s.BackdropUrl ?? s.PosterUrl, Stretch = Stretch.UniformToFill });
        body.Children.Add(banner);

        var info = new StackPanel { Spacing = 10, Margin = new(20, 0) };
        info.Children.Add(new TextBlock { Text = s.Title, FontSize = 26, FontWeight = FontWeight.Black, TextWrapping = TextWrapping.Wrap });
        var meta = new WrapPanel { Orientation = Orientation.Horizontal };
        if (s.Year is int y) meta.Children.Add(Chip(y.ToString()));
        if (!string.IsNullOrEmpty(s.Genres))
            foreach (var g in s.Genres.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries).Take(4))
                meta.Children.Add(Chip(g));
        info.Children.Add(meta);
        if (!string.IsNullOrEmpty(s.Overview))
            info.Children.Add(new TextBlock { Text = s.Overview, TextWrapping = TextWrapping.Wrap, Foreground = new SolidColorBrush(Color.FromRgb(0xDD, 0xDD, 0xDD)) });

        var fav = new Button { Content = (s.IsFavorite ?? false) ? "★ In My List" : "☆ My List", };
        fav.Classes.Add("movi-ghost");
        fav.Click += async (_, _) =>
        {
            try
            {
                if (s.IsFavorite ?? false) await ApiClient.Shared.FavoriteRemoveAsync("show", s.Id);
                else await ApiClient.Shared.FavoriteAddAsync("show", s.Id);
                s.IsFavorite = !(s.IsFavorite ?? false);
                fav.Content = (s.IsFavorite ?? false) ? "★ In My List" : "☆ My List";
            }
            catch (ApiException ex) { Ui.ShowError(this.FindControl<TextBlock>("ErrorText")!, ex.Message); }
        };
        info.Children.Add(fav);
        body.Children.Add(info);

        if (s.Seasons is { Count: > 0 } seasons)
        {
            var seasonPanel = new StackPanel { Spacing = 4, Margin = new(20, 8, 20, 0) };
            seasonPanel.Children.Add(new TextBlock { Text = "Episodes", FontSize = 18, FontWeight = FontWeight.Bold, Margin = new(0, 0, 0, 8) });
            // Season picker
            if (seasons.Count > 1)
            {
                var picker = new ComboBox
                {
                    ItemsSource = seasons.Select((sn, i) => $"Season {sn.SeasonNumber ?? i + 1}").ToList(),
                    SelectedIndex = 0, Margin = new(0, 0, 0, 8), MaxWidth = 220,
                };
                var epHost = new StackPanel { Spacing = 8 };
                picker.SelectionChanged += (_, _) =>
                {
                    epHost.Children.Clear();
                    AddEpisodes(epHost, seasons[picker.SelectedIndex], s);
                };
                seasonPanel.Children.Add(picker);
                seasonPanel.Children.Add(epHost);
                AddEpisodes(epHost, seasons[0], s);
            }
            else
            {
                AddEpisodes(seasonPanel, seasons[0], s);
            }
            body.Children.Add(seasonPanel);
        }
    }

    private void AddEpisodes(StackPanel host, Season season, ShowDetail show)
    {
        foreach (var ep in season.Episodes ?? Enumerable.Empty<Episode>())
            host.Children.Add(EpisodeRow(ep, show));
    }

    private Control EpisodeRow(Episode ep, ShowDetail show)
    {
        var grid = new Grid { ColumnDefinitions = new("96,*,Auto") };
        var still = new Border
        {
            CornerRadius = new(6), ClipToBounds = true, Width = 96, Height = 54,
            Background = new SolidColorBrush(Color.FromRgb(0x1A, 0x1A, 0x24)),
            Child = new AsyncImage { Url = ep.StillUrl, Stretch = Stretch.UniformToFill },
        };
        if (ep.Progress is double p)
        {
            var wrap = new Grid();
            wrap.Children.Add(still);
            wrap.Children.Add(new ProgressBar
            {
                Value = p * 100, Maximum = 100, Height = 3,
                VerticalAlignment = VerticalAlignment.Bottom,
                Foreground = new SolidColorBrush(Color.FromRgb(0xE5, 0x09, 0x14)),
            });
            grid.Children.Add(wrap);
        }
        else grid.Children.Add(still);

        var text = new StackPanel { Spacing = 4, Margin = new(12, 0), VerticalAlignment = VerticalAlignment.Center };
        Grid.SetColumn(text, 1);
        text.Children.Add(new TextBlock { Text = ep.Label, FontWeight = FontWeight.Bold, TextWrapping = TextWrapping.Wrap });
        if (!string.IsNullOrEmpty(ep.Overview))
            text.Children.Add(new TextBlock { Text = ep.Overview, FontSize = 12, Foreground = new SolidColorBrush(Color.FromRgb(0x8E, 0x8E, 0x99)), MaxLines = 2, TextTrimming = TextTrimming.CharacterEllipsis });
        grid.Children.Add(text);

        var btns = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 4, VerticalAlignment = VerticalAlignment.Center };
        Grid.SetColumn(btns, 2);
        var play = new Button { Content = "▶", };
        play.Classes.Add("movi-ghost");
        play.Click += (_, _) => AppState.Shared.RequestPlay(new PlayRequest { Kind = "episode", ItemId = ep.Id, Title = $"{show.Title} — {ep.Label}" });
        var dlState = DownloadManager.Shared.Find("episode", ep.Id);
        var dl = new Button { Content = dlState?.State == DownloadState.Done ? "✓" : "⭳", };
        dl.Classes.Add("movi-ghost");
        dl.Click += (_, _) =>
        {
            DownloadManager.Shared.Start("episode", ep.Id, $"{show.Title} — {ep.Label}", ep.StillUrl);
            dl.Content = "…";
        };
        btns.Children.Add(play); btns.Children.Add(dl);
        grid.Children.Add(btns);

        var wrap2 = new Button
        {
            Content = grid, Background = Brushes.Transparent,
            Padding = new(0, 6), BorderThickness = new(0),
            HorizontalAlignment = HorizontalAlignment.Stretch,
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
        };
        wrap2.Click += (_, _) => AppState.Shared.RequestPlay(new PlayRequest { Kind = "episode", ItemId = ep.Id, Title = $"{show.Title} — {ep.Label}" });
        return wrap2;
    }

    private static Border Chip(string text)
        => new()
        {
            CornerRadius = new(4),
            Background = new SolidColorBrush(Color.FromRgb(0x2A, 0x2A, 0x36)),
            Padding = new(8, 4), Margin = new(0, 0, 8, 8),
            Child = new TextBlock { Text = text, FontSize = 12, Foreground = new SolidColorBrush(Color.FromRgb(0xCC, 0xCC, 0xCC)) },
        };

    private void InitializeComponent() => AvaloniaXamlLoader.Load(this);
}
