using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using Avalonia.Media;
using Movi.Models;
using Movi.Services;

namespace Movi.Views;

public partial class ProfilesView : UserControl
{
    public ProfilesView()
    {
        InitializeComponent();
        _ = LoadAsync();
    }

    private async Task LoadAsync()
    {
        var wrap = this.FindControl<WrapPanel>("ProfileWrap")!;
        try
        {
            var resp = await ApiClient.Shared.GetProfilesAsync();
            wrap.Children.Clear();
            foreach (var p in resp.Profiles)
                wrap.Children.Add(MakeTile(p));
        }
        catch (ApiException ex) { ShowError(ex.Message); }
    }

    private Control MakeTile(Profile p)
    {
        var brush = BrushFromHex(p.Color);
        var btn = new Button
        {
            Width = 110, Height = 130, Margin = new(8),
            CornerRadius = new(12),
            Background = new SolidColorBrush(Color.FromRgb(0x1A, 0x1A, 0x24)),
        };
        var stack = new StackPanel { Spacing = 10, HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Center, VerticalAlignment = Avalonia.Layout.VerticalAlignment.Center };
        stack.Children.Add(new Border
        {
            Width = 72, Height = 72, CornerRadius = new(36),
            Background = brush,
            Child = new TextBlock
            {
                Text = string.IsNullOrEmpty(p.Name) ? "?" : p.Name[..1].ToString().ToUpper(),
                FontSize = 32, FontWeight = Avalonia.Media.FontWeight.Bold,
                Foreground = Brushes.White,
                HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Center,
                VerticalAlignment = Avalonia.Layout.VerticalAlignment.Center,
            }
        });
        stack.Children.Add(new TextBlock
        {
            Text = p.Name, Foreground = Brushes.White,
            HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Center,
            TextWrapping = Avalonia.Media.TextWrapping.Wrap,
        });
        btn.Content = stack;
        btn.Click += async (_, _) =>
        {
            try
            {
                await ApiClient.Shared.SelectProfileAsync(p.Id);
                AppState.Shared.Profile = p;
                AppState.Shared.Screen = AppScreen.Main;
            }
            catch (ApiException ex) { ShowError(ex.Message); }
        };
        return btn;
    }

    private static IBrush BrushFromHex(string hex)
    {
        try
        {
            hex = hex.TrimStart('#');
            if (hex.Length == 6)
                return new SolidColorBrush(Color.FromRgb(
                    Convert.ToByte(hex[..2], 16),
                    Convert.ToByte(hex.Substring(2, 2), 16),
                    Convert.ToByte(hex.Substring(4, 2), 16)));
        }
        catch { }
        return new SolidColorBrush(Color.FromRgb(0xE5, 0x09, 0x14));
    }

    private void ShowError(string msg)
    {
        var t = this.FindControl<TextBlock>("ErrorText")!;
        t.Text = msg; t.IsVisible = true;
    }

    private void InitializeComponent() => AvaloniaXamlLoader.Load(this);
}
