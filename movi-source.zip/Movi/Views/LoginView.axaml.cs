using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using Movi.Services;

namespace Movi.Views;

public partial class LoginView : UserControl
{
    private bool _busy;

    public LoginView()
    {
        InitializeComponent();
        var email = this.FindControl<TextBox>("EmailBox")!;
        var pass = this.FindControl<TextBox>("PasswordBox")!;
        var btn = this.FindControl<Button>("LoginButton")!;
        btn.Click += async (_, _) => await DoLogin(email.Text ?? "", pass.Text ?? "");
        pass.KeyDown += async (_, e) =>
        {
            if (e.Key == Key.Enter) await DoLogin(email.Text ?? "", pass.Text ?? "");
        };
    }

    private async Task DoLogin(string email, string password)
    {
        if (_busy || string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password)) return;
        _busy = true;
        SetError(null);
        try
        {
            var resp = await ApiClient.Shared.LoginAsync(email.Trim(), password);
            if (!resp.Ok || resp.User == null)
            {
                SetError(resp.Error ?? "Login failed.");
                return;
            }
            AppState.Shared.User = resp.User;
            AppState.Shared.Screen = AppScreen.Profiles;
        }
        catch (ApiException ex) { SetError(ex.Message); }
        finally { _busy = false; }
    }

    private void SetError(string? msg)
    {
        var t = this.FindControl<TextBlock>("ErrorText")!;
        t.Text = msg ?? "";
        t.IsVisible = msg != null;
    }

    private void InitializeComponent() => AvaloniaXamlLoader.Load(this);
}
