using Avalonia.Controls;
using Avalonia.Media.Imaging;
using Avalonia.Threading;
using Movi.Services;

namespace Movi.Views;

/// An Image that loads its bitmap from a URL asynchronously (with cache).
public class AsyncImage : Image
{
    public static readonly Avalonia.StyledProperty<string?> UrlProperty =
        Avalonia.AvaloniaProperty.Register<AsyncImage, string?>(nameof(Url));

    public string? Url
    {
        get => GetValue(UrlProperty);
        set => SetValue(UrlProperty, value);
    }

    protected override void OnPropertyChanged(Avalonia.AvaloniaPropertyChangedEventArgs change)
    {
        base.OnPropertyChanged(change);
        if (change.Property == UrlProperty) Load();
    }

    private async void Load()
    {
        var url = Url;
        Source = null;
        if (string.IsNullOrEmpty(url)) return;
        var bmp = await ImageCache.GetAsync(url);
        await Dispatcher.UIThread.InvokeAsync(() =>
        {
            if (Url == url) Source = bmp;
        });
    }
}

public static class Ui
{
    /// A tappable poster card (2:3) with optional progress bar.
    public static Control PosterCard(Models.HomeItem item, Action onTap, double width = 110)
    {
        var grid = new Grid { Width = width, Margin = new(0, 0, 10, 0) };
        grid.RowDefinitions.Add(new(Avalonia.Controls.GridLength.Star));
        grid.RowDefinitions.Add(new(Avalonia.Controls.GridLength.Auto));

        var img = new AsyncImage
        {
            Url = item.PosterUrl,
            Width = width, Height = width * 1.5,
            Stretch = Avalonia.Media.Stretch.UniformToFill,
        };
        var border = new Border
        {
            CornerRadius = new(8),
            ClipToBounds = true,
            Background = new Avalonia.Media.SolidColorBrush(Avalonia.Media.Color.FromRgb(0x1A, 0x1A, 0x24)),
            Child = img,
        };
        Grid.SetRow(border, 0);

        var stack = new StackPanel { Spacing = 2, Margin = new(0, 6, 0, 0) };
        Grid.SetRow(stack, 1);

        if (item.Progress is double p)
        {
            stack.Children.Add(new ProgressBar
            {
                Value = p * 100, Maximum = 100, Height = 3,
                Foreground = new Avalonia.Media.SolidColorBrush(Avalonia.Media.Color.FromRgb(0xE5, 0x09, 0x14)),
                Background = new Avalonia.Media.SolidColorBrush(Avalonia.Media.Color.FromRgb(0x33, 0x33, 0x33)),
            });
        }
        var title = new TextBlock
        {
            Text = item.DisplayTitle,
            FontSize = 12, TextWrapping = Avalonia.Media.TextWrapping.Wrap,
            MaxLines = 2, TextTrimming = Avalonia.Media.TextTrimming.CharacterEllipsis,
        };
        stack.Children.Add(title);
        if (!string.IsNullOrEmpty(item.ShowTitle) && item.SeasonNo is int sn && item.EpisodeNo is int en)
            stack.Children.Add(new TextBlock
            {
                Text = $"S{sn}:E{en}", FontSize = 11,
                Foreground = new Avalonia.Media.SolidColorBrush(Avalonia.Media.Color.FromRgb(0x8E, 0x8E, 0x99)),
            });
        else if (item.Year is int y)
            stack.Children.Add(new TextBlock
            {
                Text = y.ToString(), FontSize = 11,
                Foreground = new Avalonia.Media.SolidColorBrush(Avalonia.Media.Color.FromRgb(0x8E, 0x8E, 0x99)),
            });

        grid.Children.Add(border);
        grid.Children.Add(stack);

        var btn = new Button
        {
            Content = grid, Background = Avalonia.Media.Brushes.Transparent,
            Padding = new(0), BorderThickness = new(0),
        };
        btn.Click += (_, _) => onTap();
        return btn;
    }

    public static T Styled<T>(T control, string cls) where T : Avalonia.StyledElement
    {
        control.Classes.Add(cls);
        return control;
    }

    public static TextBlock ErrorText()
        => new() { Foreground = new Avalonia.Media.SolidColorBrush(Avalonia.Media.Color.FromRgb(0xE5, 0x09, 0x14)), TextWrapping = Avalonia.Media.TextWrapping.Wrap, IsVisible = false, Margin = new(0, 8) };

    public static void ShowError(TextBlock t, string msg) { t.Text = msg; t.IsVisible = true; }
}
