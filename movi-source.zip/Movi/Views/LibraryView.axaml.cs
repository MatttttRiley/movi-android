using Avalonia.Controls;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Media;
using Movi.Models;
using Movi.Services;

namespace Movi.Views;

public partial class LibraryView : UserControl, IRefreshable
{
    public LibraryView()
    {
        InitializeComponent();
        _ = LoadAsync();
    }

    public void Refresh() => _ = LoadAsync();

    private async Task LoadAsync()
    {
        var body = this.FindControl<StackPanel>("Body")!;
        var err = this.FindControl<TextBlock>("ErrorText")!;
        var spinner = this.FindControl<ProgressBar>("Spinner")!;
        spinner.IsVisible = true; err.IsVisible = false;
        try
        {
            var fav = await ApiClient.Shared.GetFavoritesAsync();
            body.Children.Clear();
            AddSection(body, "Movies", fav.Movies, "movie");
            AddSection(body, "Shows", fav.Shows, "show");
            if ((fav.Movies?.Count ?? 0) + (fav.Shows?.Count ?? 0) == 0)
                body.Children.Add(new TextBlock
                {
                    Text = "Your list is empty. Tap ☆ My List on anything to save it here.",
                    Foreground = new SolidColorBrush(Color.FromRgb(0x8E, 0x8E, 0x99)),
                    TextWrapping = TextWrapping.Wrap,
                });
        }
        catch (ApiException ex)
        {
            if (ex.SessionExpired) AppState.Shared.OnSessionExpired();
            else Ui.ShowError(err, ex.Message);
        }
        finally { spinner.IsVisible = false; }
    }

    private static void AddSection(StackPanel host, string title, List<HomeItem>? items, string kind)
    {
        if (items is not { Count: > 0 }) return;
        host.Children.Add(new TextBlock { Text = title, FontSize = 17, FontWeight = FontWeight.Bold });
        var wrap = new WrapPanel { Orientation = Orientation.Horizontal };
        foreach (var item in items)
        {
            var captured = item;
            captured.Kind = kind;
            wrap.Children.Add(Ui.PosterCard(captured, () =>
            {
                if (kind == "movie") AppState.Shared.PushView(new MovieDetailView(captured.ItemId));
                else AppState.Shared.PushView(new ShowDetailView(captured.ItemId));
            }, 100));
        }
        host.Children.Add(wrap);
    }

    private void InitializeComponent() => AvaloniaXamlLoader.Load(this);
}
