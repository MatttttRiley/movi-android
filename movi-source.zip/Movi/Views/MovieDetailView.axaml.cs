using Avalonia.Controls;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Media;
using Movi.Models;
using Movi.Services;

namespace Movi.Views;

public partial class MovieDetailView : UserControl
{
    private readonly int _id;
    private MovieDetail? _movie;

    public MovieDetailView(int id)
    {
        _id = id;
        InitializeComponent();
        this.FindControl<Button>("BackButton")!.Click += (_, _) => AppState.Shared.PopView();
        _ = LoadAsync();
    }

    private async Task LoadAsync()
    {
        var body = this.FindControl<StackPanel>("Body")!;
        var err = this.FindControl<TextBlock>("ErrorText")!;
        var spinner = this.FindControl<ProgressBar>("Spinner")!;
        spinner.IsVisible = true;
        try
        {
            _movie = await ApiClient.Shared.GetMovieAsync(_id);
            body.Children.Clear();
            BuildBody(body, _movie);
        }
        catch (ApiException ex)
        {
            if (ex.SessionExpired) AppState.Shared.OnSessionExpired();
            else Ui.ShowError(err, ex.Message);
        }
        finally { spinner.IsVisible = false; }
    }

    private void BuildBody(StackPanel body, MovieDetail m)
    {
        var banner = new Grid { Height = 220 };
        banner.Children.Add(new AsyncImage { Url = m.BackdropUrl ?? m.PosterUrl, Stretch = Stretch.UniformToFill });
        body.Children.Add(banner);

        var info = new StackPanel { Spacing = 10, Margin = new(20, 0) };
        info.Children.Add(new TextBlock { Text = m.Title, FontSize = 26, FontWeight = FontWeight.Black, TextWrapping = TextWrapping.Wrap });
        var meta = new WrapPanel { Orientation = Orientation.Horizontal };
        if (m.Year is int y) meta.Children.Add(MetaChip(y.ToString()));
        if (!string.IsNullOrEmpty(m.Genres))
            foreach (var g in m.Genres.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries).Take(4))
                meta.Children.Add(MetaChip(g));
        info.Children.Add(meta);
        if (!string.IsNullOrEmpty(m.Overview))
            info.Children.Add(new TextBlock { Text = m.Overview, TextWrapping = TextWrapping.Wrap, Foreground = new SolidColorBrush(Color.FromRgb(0xDD, 0xDD, 0xDD)) });

        var btns = new WrapPanel { Orientation = Orientation.Horizontal };
        var play = new Button { Content = "▶  Play", Margin = new(0, 0, 10, 10) };
        play.Classes.Add("movi-primary");
        play.Click += (_, _) => AppState.Shared.RequestPlay(new PlayRequest { Kind = "movie", ItemId = m.Id, Title = m.Title });
        btns.Children.Add(play);

        var dlState = DownloadManager.Shared.Find("movie", m.Id);
        var dl = new Button { Content = dlState?.State == DownloadState.Done ? "✓ Downloaded" : "⭳ Download", Margin = new(0, 0, 10, 10) };
        dl.Classes.Add("movi-ghost");
        dl.Click += (_, _) =>
        {
            DownloadManager.Shared.Start("movie", m.Id, m.Title, m.PosterUrl);
            dl.Content = "⭳ Queued — see Downloads";
        };
        btns.Children.Add(dl);

        var fav = new Button { Content = (m.IsFavorite ?? false) ? "★ In My List" : "☆ My List", Margin = new(0, 0, 10, 10) };
        fav.Classes.Add("movi-ghost");
        fav.Click += async (_, _) =>
        {
            try
            {
                if (m.IsFavorite ?? false) await ApiClient.Shared.FavoriteRemoveAsync("movie", m.Id);
                else await ApiClient.Shared.FavoriteAddAsync("movie", m.Id);
                m.IsFavorite = !(m.IsFavorite ?? false);
                fav.Content = (m.IsFavorite ?? false) ? "★ In My List" : "☆ My List";
            }
            catch (ApiException ex) { Ui.ShowError(this.FindControl<TextBlock>("ErrorText")!, ex.Message); }
        };
        btns.Children.Add(fav);
        info.Children.Add(btns);
        body.Children.Add(info);
    }

    private static Border MetaChip(string text)
        => new()
        {
            CornerRadius = new(4),
            Background = new SolidColorBrush(Color.FromRgb(0x2A, 0x2A, 0x36)),
            Padding = new(8, 4), Margin = new(0, 0, 8, 8),
            Child = new TextBlock { Text = text, FontSize = 12, Foreground = new SolidColorBrush(Color.FromRgb(0xCC, 0xCC, 0xCC)) },
        };

    private void InitializeComponent() => AvaloniaXamlLoader.Load(this);
}
