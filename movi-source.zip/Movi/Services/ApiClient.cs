using System.Net;
using System.Text;
using System.Text.Json;
using Movi.Models;

namespace Movi.Services;

public class ApiException : Exception
{
    public bool SessionExpired { get; }
    public ApiException(string message, bool sessionExpired = false) : base(message)
        => SessionExpired = sessionExpired;
}

public class ApiClient
{
    public static ApiClient Shared { get; } = new();

    private const string BaseUrl = "https://movi.webs.vc/api.php";
    private readonly HttpClient _http;
    private readonly JsonSerializerOptions _json;

    private ApiClient()
    {
        var handler = new HttpClientHandler
        {
            UseCookies = true,
            CookieContainer = new CookieContainer(),
            AutomaticDecompression = DecompressionMethods.All,
        };
        _http = new HttpClient(handler) { Timeout = TimeSpan.FromSeconds(30) };
        _json = new JsonSerializerOptions { PropertyNameCaseInsensitive = false };
    }

    private static string BuildUrl(string api, Dictionary<string, string>? @params = null)
    {
        var sb = new StringBuilder(BaseUrl).Append("?api=").Append(Uri.EscapeDataString(api));
        if (@params != null)
            foreach (var (k, v) in @params)
                sb.Append('&').Append(Uri.EscapeDataString(k)).Append('=').Append(Uri.EscapeDataString(v));
        return sb.ToString();
    }

    private static string FormEncode(Dictionary<string, string> fields)
    {
        static string Esc(string s)
        {
            var sb = new StringBuilder();
            foreach (var c in s)
            {
                if (c is >= 'a' and <= 'z' or >= 'A' and <= 'Z' or >= '0' and <= '9'
                    or '-' or '_' or '.' or '~')
                    sb.Append(c);
                else if (c == ' ') sb.Append('+');
                else sb.Append('%').Append(((int)c).ToString("X2"));
            }
            return sb.ToString();
        }
        return string.Join("&", fields.Select(kv => $"{Esc(kv.Key)}={Esc(kv.Value)}"));
    }

    private async Task<T> GetAsync<T>(string api, Dictionary<string, string>? @params = null)
    {
        HttpResponseMessage resp;
        try { resp = await _http.GetAsync(BuildUrl(api, @params)); }
        catch (Exception) { throw new ApiException("Couldn't reach the server."); }
        return await ReadAsync<T>(resp);
    }

    public async Task<string> PostFormRawAsync(string api, Dictionary<string, string> fields)
    {
        HttpResponseMessage resp;
        try
        {
            var content = new StringContent(FormEncode(fields), Encoding.UTF8,
                "application/x-www-form-urlencoded");
            resp = await _http.PostAsync(BuildUrl(api), content);
        }
        catch (Exception) { throw new ApiException("Couldn't reach the server."); }
        var body = await resp.Content.ReadAsStringAsync();
        Check(resp, body);
        return body;
    }

    public Task PostFormAsync(string api, Dictionary<string, string> fields)
        => PostFormRawAsync(api, fields);

    private async Task<T> ReadAsync<T>(HttpResponseMessage resp)
    {
        var body = await resp.Content.ReadAsStringAsync();
        Check(resp, body);
        try { return JsonSerializer.Deserialize<T>(body, _json)!; }
        catch (Exception) { throw new ApiException("Bad response from server."); }
    }

    private static void Check(HttpResponseMessage resp, string body)
    {
        if (!resp.IsSuccessStatusCode)
        {
            string msg = $"Server error ({(int)resp.StatusCode}).";
            try
            {
                using var doc = JsonDocument.Parse(body);
                if (doc.RootElement.TryGetProperty("error", out var e))
                    msg = e.GetString() ?? msg;
            }
            catch { /* ignore */ }
            throw new ApiException(msg);
        }
        var prefix = body.TrimStart();
        if (prefix.StartsWith("<"))
            throw new ApiException("Your session expired. Please log in again.", sessionExpired: true);
    }

    // ---------- Endpoints ----------

    public async Task<LoginResponse> LoginAsync(string email, string password)
    {
        var body = await PostFormRawAsync("app_login",
            new() { ["email"] = email, ["password"] = password });
        return JsonSerializer.Deserialize<LoginResponse>(body, _json)!;
    }

    public Task LogoutAsync() => PostFormAsync("app_logout", new());

    public Task<ProfilesResponse> GetProfilesAsync() => GetAsync<ProfilesResponse>("app_profiles");

    public Task SelectProfileAsync(int profileId) =>
        PostFormAsync("app_profile_select", new() { ["profile_id"] = profileId.ToString() });

    public Task<HomeResponse> GetHomeAsync() => GetAsync<HomeResponse>("app_home");

    public Task<MovieDetail> GetMovieAsync(int id) =>
        GetAsync<MovieDetail>("movie", new() { ["id"] = id.ToString() });

    public Task<ShowDetail> GetShowAsync(int id) =>
        GetAsync<ShowDetail>("show", new() { ["id"] = id.ToString() });

    public Task<EpisodeDetail> GetEpisodeAsync(int id) =>
        GetAsync<EpisodeDetail>("episode", new() { ["id"] = id.ToString() });

    public Task<SearchResponse> SearchAsync(string q) =>
        GetAsync<SearchResponse>("search", new() { ["q"] = q });

    public Task<FavoritesResponse> GetFavoritesAsync() => GetAsync<FavoritesResponse>("favorites_list");

    public Task FavoriteAddAsync(string kind, int id) =>
        PostFormAsync("favorites_add", new() { ["kind"] = kind, ["id"] = id.ToString() });

    public Task FavoriteRemoveAsync(string kind, int id) =>
        PostFormAsync("favorites_remove", new() { ["kind"] = kind, ["id"] = id.ToString() });

    public Task ReportProgressAsync(string kind, int id, double position, double duration) =>
        PostFormAsync("watch_progress", new()
        {
            ["kind"] = kind, ["id"] = id.ToString(),
            ["position"] = position.ToString("F1"),
            ["duration"] = duration.ToString("F1"),
        });

    public async Task<DownloadStartResponse> DownloadStartAsync(string kind, int id)
    {
        var body = await PostFormRawAsync("app_download_start",
            new() { ["kind"] = kind, ["id"] = id.ToString() });
        return JsonSerializer.Deserialize<DownloadStartResponse>(body, _json)!;
    }

    public Task<DownloadStatusResponse> DownloadStatusAsync(string jobId) =>
        GetAsync<DownloadStatusResponse>("download_status", new() { ["job_id"] = jobId });
}
