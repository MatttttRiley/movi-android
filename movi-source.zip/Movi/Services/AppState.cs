using System.ComponentModel;
using System.Runtime.CompilerServices;
using Avalonia.Controls;
using Movi.Models;

namespace Movi.Services;

/// Minimal INotifyPropertyChanged base (avoids source-generator issues).
public abstract class ObservableBase : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler? PropertyChanged;

    protected bool Set<T>(ref T field, T value, [CallerMemberName] string? name = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value)) return false;
        field = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        return true;
    }

    protected void Raise([CallerMemberName] string? name = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}

public enum AppScreen { Login, Profiles, Main }

/// Where the player should go.
public class PlayRequest
{
    public string Kind = ""; // "movie" | "episode"
    public int ItemId;
    public string Title = "";
    /// If set, play this local file instead of streaming.
    public string? LocalPath;
}

/// Global app state + navigation.
public class AppState : ObservableBase
{
    public static AppState Shared { get; } = new();

    private AppScreen _screen = AppScreen.Login;
    public AppScreen Screen { get => _screen; set => Set(ref _screen, value); }

    private UserControl? _mainContent;
    /// The view currently shown inside the main shell.
    public UserControl? MainContent { get => _mainContent; set => Set(ref _mainContent, value); }

    private int _mainTab;
    /// 0=Home 1=Search 2=My List 3=Downloads
    public int MainTab { get => _mainTab; set => Set(ref _mainTab, value); }

    public ApiUser? User { get; set; }
    public Profile? Profile { get; set; }

    private string _error = "";
    public string Error { get => _error; set => Set(ref _error, value); }

    public event Action<PlayRequest>? PlayRequested;

    public void RequestPlay(PlayRequest req) => PlayRequested?.Invoke(req);

    /// Set by MainTabsView; views use this to push detail pages.
    public Views.MainTabsView? Tabs { get; set; }
    public void PushView(UserControl view) => Tabs?.Push(view);
    public void PopView() => Tabs?.Pop();

    public void GoHome() => MainTab = 0;

    public void Logout()
    {
        User = null; Profile = null;
        MainContent = null;
        Screen = AppScreen.Login;
    }

    public void OnSessionExpired()
    {
        Logout();
        Error = "Your session expired. Please log in again.";
    }
}
