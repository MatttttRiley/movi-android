using Avalonia.Media.Imaging;

namespace Movi.Services;

/// Tiny in-memory poster image cache.
public static class ImageCache
{
    private static readonly Dictionary<string, Bitmap?> _cache = new();
    private static readonly HttpClient _http = new() { Timeout = TimeSpan.FromSeconds(20) };

    public static async Task<Bitmap?> GetAsync(string? url)
    {
        if (string.IsNullOrEmpty(url)) return null;
        lock (_cache)
        {
            if (_cache.TryGetValue(url, out var bmp)) return bmp;
        }
        try
        {
            var data = await _http.GetByteArrayAsync(url);
            using var ms = new MemoryStream(data);
            var bitmap = new Bitmap(ms);
            lock (_cache)
            {
                if (_cache.Count > 200) _cache.Clear();
                _cache[url] = bitmap;
            }
            return bitmap;
        }
        catch
        {
            lock (_cache) _cache[url] = null;
            return null;
        }
    }
}
