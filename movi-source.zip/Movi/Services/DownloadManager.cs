using System.Text.Json;
using Movi.Models;

namespace Movi.Services;

/// Offline downloads: app_download_start -> poll download_status ->
/// fetch single-use dl_url into app-private storage.
public class DownloadManager : ObservableBase
{
    public static DownloadManager Shared { get; } = new();

    private readonly List<DownloadItem> _items = new();
    public IReadOnlyList<DownloadItem> Items => _items;

    public event Action? Changed;
    private void Notify() { Raise(nameof(Items)); Changed?.Invoke(); }

    public static string DownloadsDir
    {
        get
        {
            var dir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Movi", "Downloads");
            Directory.CreateDirectory(dir);
            return dir;
        }
    }

    private static string MetaPath => Path.Combine(DownloadsDir, "downloads.json");

    private readonly HttpClient _http = new() { Timeout = TimeSpan.FromHours(2) };
    private readonly JsonSerializerOptions _json = new();

    public DownloadManager() => Load();

    public DownloadItem? Find(string kind, int libraryId)
        => _items.FirstOrDefault(i => i.Kind == kind && i.LibraryId == libraryId);

    public string? LocalPath(DownloadItem item)
    {
        if (item.State != DownloadState.Done || string.IsNullOrEmpty(item.Filename)) return null;
        var p = Path.Combine(DownloadsDir, item.Filename);
        return File.Exists(p) ? p : null;
    }

    public void Start(string kind, int libraryId, string title, string? posterUrl)
    {
        _items.RemoveAll(i => i.Kind == kind && i.LibraryId == libraryId && i.State == DownloadState.Failed);
        if (Find(kind, libraryId) != null) return;
        var item = new DownloadItem
        {
            Kind = kind, LibraryId = libraryId, Title = title, PosterUrl = posterUrl,
            State = DownloadState.Preparing, Progress = 0,
        };
        _items.Insert(0, item);
        Save(); Notify();
        _ = RunAsync(item);
    }

    public void Delete(DownloadItem item)
    {
        try
        {
            if (!string.IsNullOrEmpty(item.Filename))
            {
                var p = Path.Combine(DownloadsDir, item.Filename);
                if (File.Exists(p)) File.Delete(p);
            }
        }
        catch { /* ignore */ }
        _items.Remove(item);
        Save(); Notify();
    }

    private async Task RunAsync(DownloadItem item)
    {
        try
        {
            var started = await ApiClient.Shared.DownloadStartAsync(item.Kind, item.LibraryId);
            if (string.IsNullOrEmpty(started.JobId))
            {
                Fail(item);
                return;
            }
            item.JobId = started.JobId;

            string? dlUrl = null;
            string filename = "video.mp4";
            for (int i = 0; i < 120; i++) // ~6 min of preparing max
            {
                await Task.Delay(3000);
                var st = await ApiClient.Shared.DownloadStatusAsync(started.JobId);
                item.State = st.Status == "downloading" ? DownloadState.Downloading : DownloadState.Preparing;
                item.Progress = (st.Progress ?? 0) * 0.5;
                Notify();
                if (st.Status == "done" && !string.IsNullOrEmpty(st.DlUrl))
                {
                    dlUrl = st.DlUrl;
                    if (!string.IsNullOrEmpty(st.Filename)) filename = st.Filename;
                    break;
                }
                if (st.Status is "failed" or "cancelled") { Fail(item); return; }
            }
            if (dlUrl == null) { Fail(item); return; }

            await FetchFileAsync(item, dlUrl, filename);
        }
        catch { Fail(item); }
    }

    private async Task FetchFileAsync(DownloadItem item, string url, string filename)
    {
        var safe = string.Concat(filename.Split(Path.GetInvalidFileNameChars()));
        if (string.IsNullOrWhiteSpace(safe)) safe = "video.mp4";
        var dest = Path.Combine(DownloadsDir, safe);
        try
        {
            using var resp = await _http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead);
            resp.EnsureSuccessStatusCode();
            var total = resp.Content.Headers.ContentLength ?? -1;
            await using var net = await resp.Content.ReadAsStreamAsync();
            await using var file = File.Create(dest);
            var buf = new byte[81920];
            long read = 0;
            int n;
            while ((n = await net.ReadAsync(buf)) > 0)
            {
                await file.WriteAsync(buf.AsMemory(0, n));
                read += n;
                if (total > 0)
                {
                    item.State = DownloadState.Downloading;
                    item.Progress = 0.5 + 0.5 * read / total;
                    Notify();
                }
            }
            item.State = DownloadState.Done;
            item.Progress = 1;
            item.Filename = safe;
            item.SizeBytes = new FileInfo(dest).Length;
            item.DownloadedAt = DateTime.UtcNow;
        }
        catch
        {
            try { if (File.Exists(dest)) File.Delete(dest); } catch { }
            Fail(item);
            return;
        }
        Save(); Notify();
    }

    private void Fail(DownloadItem item)
    {
        item.State = DownloadState.Failed;
        item.Progress = 0;
        Save(); Notify();
    }

    private void Load()
    {
        try
        {
            if (!File.Exists(MetaPath)) return;
            var items = JsonSerializer.Deserialize<List<DownloadItem>>(
                File.ReadAllText(MetaPath), _json);
            if (items == null) return;
            foreach (var it in items)
            {
                // Jobs/tokens don't survive a relaunch.
                if (it.State != DownloadState.Done || LocalPath(it) == null)
                {
                    it.State = DownloadState.Failed;
                    it.Progress = 0;
                }
                _items.Add(it);
            }
        }
        catch { /* ignore */ }
    }

    private void Save()
    {
        try { File.WriteAllText(MetaPath, JsonSerializer.Serialize(_items, _json)); }
        catch { /* ignore */ }
    }
}
